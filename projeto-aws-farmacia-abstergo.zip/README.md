# Projeto AWS - Farmácia Abstergo

## Objetivo
Implementação de infraestrutura AWS para sistema de farmácia com foco em redução de custos.

## Serviços Utilizados
- Amazon EC2
- Amazon S3
- Amazon S3 Glacier
- AWS Cost Explorer
- Amazon RDS

## Funcionalidades
- Controle de estoque
- Cadastro de clientes
- Registro de vendas
- Armazenamento de receitas
- Backup automático

## Responsável
Luiz Henrique Boger Wessling
